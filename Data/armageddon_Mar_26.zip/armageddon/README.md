## Resources armageddon - No Description
